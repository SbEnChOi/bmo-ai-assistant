"""Load server-side keys from the environment or a local, untracked config file."""
import os


def api_key(name):
    try:
        from . import private_config
    except ImportError as exc:
        if exc.name not in ("bmo.private_config", "private_config"):
            raise
        return os.environ.get(name, "").strip()
    return getattr(private_config, name, "").strip() or os.environ.get(name, "").strip()
