'use strict';
(() => {
  const el = id => document.getElementById(id), phone = window.BmoPhone, audio = el('rt-player');
  let current = null, generation = 0, shared = null;
  function status(text) { el('rt-status').textContent = text; }
  function metrics(c) {
    if (c.mock) { el('rt-metrics').textContent = '모의 연결 · 실제 지연과 사용량은 측정하지 않아요'; return; }
    const m = c.metrics;
    el('rt-metrics').textContent = `연결 ${m.connect_ms ?? '—'}ms · 출력 이벤트 ${m.reply_ms ?? '—'}ms · 끼어들기 ${m.interrupt_ms ?? '—'}ms · API 입력/출력 ${m.input_tokens}/${m.output_tokens} 토큰`;
  }
  function phase(next) {
    const c = current; if (!c) return;
    c.phase = c.muted && next === 'listening' ? 'muted' : next;
    const caption = c.phase === 'muted' ? '잠시 쉬는 중 · 다시 듣기를 누르면 이어갈게' :
      ({listening:'계속 듣고 있어! 편하게 말해 줘.',thinking:'생각하고 있어…',speaking:'이야기 중 · 끼어들어도 괜찮아'}[next] || next) + (c.muted ? ' · 마이크 꺼짐' : '');
    phone.presentPhase(c.phase, caption);
  }
  function controls() {
    const c = current;
    el('rt-start').disabled = !!c || !!shared?.realtime?.active || !shared || shared.provider !== 'openai' || phone.busy() || !window.isSecureContext || !window.RTCPeerConnection;
    el('handsfree').disabled = !c && el('rt-start').disabled;
    el('handsfree').textContent = c ? '자동 대화 종료' : '자동 대화 시작';
    el('handsfree').setAttribute('aria-pressed', String(!!c));
    el('handsfree-mute').hidden = !c || !!c.mock;
    el('handsfree-mute').disabled = !c?.id;
    el('handsfree-mute').textContent = c?.muted ? '다시 듣기' : '잠시 쉬기';
    el('rt-mock').disabled = !!c || !!shared?.realtime?.active || !shared || phone.busy();
    for (const id of ['rt-stop','rt-mute','rt-interrupt']) el(id).hidden = !c;
    el('rt-sample').hidden = !c?.mock || !c?.id;
    el('rt-mute').disabled = !!c?.mock || !c?.id;
    el('rt-interrupt').disabled = !c?.id;
    el('talk').disabled = !!c || !!shared?.realtime?.active || el('talk').disabled;
    el('talk').title = c || shared?.realtime?.active ? '자동 대화를 종료하면 눌러서 말할 수 있어요.' : '';
  }
  function send(event) {
    if (current?.dc?.readyState === 'open') { current.dc.send(JSON.stringify(event)); return true; }
    return false;
  }
  function transcript(event, role, text) {
    if (!current || !text?.trim()) return;
    const id = event.item_id || event.response_id || event.event_id;
    if (!id) return;
    current.pending.push({id: role + ':' + id, role, text: text.slice(0,4000)});
    current.pending = current.pending.slice(-24);
    el('transcript').textContent = (role === 'user' ? '내 말: ' : 'BMO: ') + text;
    void heartbeat(current);
  }
  function onEvent(event) {
    const c = current; if (!c) return;
    switch (event.type) {
      case 'session.created': c.ready = true; c.metrics.connect_ms = Math.round(performance.now()-c.started); metrics(c); status('자동 대화 연결됨 · 최대 5분'); break;
      case 'input_audio_buffer.speech_started': if (c.playing) c.interruptAt = performance.now(); phase('listening'); break;
      case 'input_audio_buffer.speech_stopped': c.replyAt = performance.now(); phase('thinking'); break;
      case 'response.created': c.responding = true; c.partial = ''; phase('thinking'); break;
      case 'response.done':
        c.responding = false;
        c.usage = event.response?.usage || c.usage;
        if (event.response?.id && !c.counted.has(event.response.id)) {
          c.counted.add(event.response.id);
          c.metrics.input_tokens += event.response.usage?.input_tokens || 0;
          c.metrics.output_tokens += event.response.usage?.output_tokens || 0;
          metrics(c);
        }
        if (event.response?.status === 'failed') status('답변 실패 · 모델 권한이나 API 사용 한도를 확인하세요.');
        if (!c.playing) phase('listening');
        break;
      case 'output_audio_buffer.started':
        if (c.replyAt != null) { c.metrics.reply_ms = Math.round(performance.now()-c.replyAt); c.replyAt = null; metrics(c); }
        c.playing = true; phase('speaking'); void playAudio(); break;
      case 'output_audio_buffer.stopped':
      case 'output_audio_buffer.cleared':
        if (c.interruptAt != null) { c.metrics.interrupt_ms = Math.round(performance.now()-c.interruptAt); c.interruptAt = null; metrics(c); }
        c.playing = false; phase(c.responding ? 'thinking' : 'listening'); break;
      case 'response.output_audio_transcript.delta':
        c.partial = (c.partial || '') + (event.delta || ''); el('transcript').textContent = 'BMO: ' + c.partial; break;
      case 'response.output_audio_transcript.done': c.partial = ''; transcript(event,'assistant',event.transcript); break;
      case 'conversation.item.input_audio_transcription.completed': transcript(event,'user',event.transcript); break;
      case 'conversation.item.input_audio_transcription.failed': status('자막 인식 실패 · 음성 대화 상태를 확인하세요.'); break;
      case 'error': c.responding = false; c.playing = false; phase('listening'); status('실시간 요청 오류 · 연결을 종료한 뒤 다시 시도하세요.'); el('error').textContent = '실시간 요청 오류 · 연결을 종료한 뒤 다시 시도해 주세요.'; break;
    }
  }
  async function playAudio() {
    try { await audio.play(); el('rt-audio').hidden = true; }
    catch { el('rt-audio').hidden = false; status('실시간 소리 켜기를 눌러주세요.'); }
  }
  async function heartbeat(c) {
    if (current !== c || !c.id || c.syncing) return;
    c.syncing = true;
    const batch = c.pending.slice(0,8);
    try {
      await phone.api('realtime/heartbeat',{session_id:c.id,phase:c.phase || 'listening',events:batch,frames_sent:c.framesSent,metrics:c.mock?{}:c.metrics});
      if (current === c) c.pending.splice(0,batch.length);
    } catch { if (current === c) await stop('PC 연결이 끊겼거나 세션이 종료됐습니다. 다시 시작할 수 있어요.'); }
    finally { c.syncing = false; }
  }
  async function frames(c) {
    if (current !== c || !c.id || !c.ready || c.framePending || !el('rt-vision').checked) return;
    if (!c.mock && (c.dc?.readyState !== 'open' || c.dc.bufferedAmount > 256000)) return;
    c.framePending = true;
    try {
      const result = await phone.api('realtime/frames',{session_id:c.id});
      if (current !== c || !el('rt-vision').checked) return;
      if (!result.frames.length) {
        if (!c.noFrames) visualAbsent(c);
        c.frameVersion = -1;
        c.noFrames = true;
        el('rt-frames').textContent = '최근 프레임 없음 · 현재 장면을 보지 못해요'; return;
      }
      if (result.version === c.frameVersion) return;
      c.noFrames = false;
      clearVisual(c);
      c.visualItems = [];
      for (const f of result.frames) {
        const itemId = 'bmo_frames_' + (++c.frameSerial);
        const content = [{type:'input_text',text:'시각 관찰 자료. 새 질문 없이 먼저 말하지 마세요. ' + f.caption},{type:'input_image',image_url:f.image_url}];
        const event = {type:'conversation.item.create',item:{id:itemId,type:'message',role:'user',content}};
        const message = JSON.stringify(event);
        if (!c.mock) {
          if (new TextEncoder().encode(message).length > (c.pc.sctp?.maxMessageSize || 65536)) throw Error('프레임이 전송 한도보다 큽니다.');
          send(event);
        }
        c.visualItems.push(itemId);
      }
      c.framesSent += result.frames.length;
      c.frameVersion = result.version;
      el('rt-frames').textContent = `${c.mock ? '모의 확인' : 'OpenAI 전송'} ${result.frames.length}장 · 누적 ${c.framesSent}장`;
    } catch { el('rt-frames').textContent = '프레임을 가져오지 못했어요'; }
    finally { c.framePending = false; }
  }
  function clearVisual(c) {
    for (const item_id of c.visualItems || []) { if (!c.mock) send({type:'conversation.item.delete',item_id}); }
    c.visualItems = [];
  }
  function visualAbsent(c) {
    clearVisual(c);
    if (c.mock) return;
    const id = 'bmo_visual_absent_'+(++c.frameSerial);
    if (send({type:'conversation.item.create',item:{id,type:'message',role:'user',content:[{type:'input_text',text:'시각 입력이 꺼졌거나 최근 프레임이 없습니다. 지금 주변을 보고 있다고 주장하지 마세요. 새 음성 질문 없이 먼저 말하지 마세요.'}]}})) c.visualItems = [id];
  }
  async function start(mock=false) {
    if (current || !shared || phone.busy() || shared.realtime?.active) return;
    const c = {generation:++generation,mock,id:null,phase:'listening',pending:[],framesSent:0,frameSerial:0,frameVersion:-1,ready:false,
      started:performance.now(),metrics:{input_tokens:0,output_tokens:0},counted:new Set()};
    current = c; phone.prepareRealtime(); el('error').textContent = ''; controls(); status(mock ? '모의 연결 중…' : '마이크 및 실시간 연결 준비 중…');
    phone.presentPhase('permission', mock ? '모의 연결 중…' : '마이크를 허용하면 자동 대화를 시작할게.');
    el('rt-mute').textContent = '마이크 끄기';
    metrics(c);
    window.BmoFace?.unlockRealtimeAudio?.(audio);
    // Prime the remote media element from this user gesture on iPad.
    if (!mock) { audio.muted = false; void audio.play().catch(()=>{}); }
    try {
      let sdp = '';
      if (!mock) {
        const stream = await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true},video:false});
        if (current !== c) { stream.getTracks().forEach(t=>t.stop()); return; }
        c.stream = stream;
        c.pc = new RTCPeerConnection();
        c.stream.getTracks().forEach(track=>c.pc.addTrack(track,c.stream));
        c.pc.ontrack = event => { if (current === c) { audio.srcObject = event.streams[0] || new MediaStream([event.track]); void playAudio(); } };
        c.pc.onconnectionstatechange = () => {
          if (current !== c) return;
          if (['failed','closed'].includes(c.pc.connectionState)) void stop('실시간 연결이 끊겼습니다. 다시 시작하세요.');
          if (c.pc.connectionState === 'disconnected' && !c.disconnectTimer) c.disconnectTimer = setTimeout(()=>{ if (current === c && c.pc.connectionState === 'disconnected') void stop('실시간 연결이 끊겼습니다. 다시 시작하세요.'); c.disconnectTimer = null; },8000);
        };
        c.dc = c.pc.createDataChannel('oai-events');
        c.dc.onmessage = message => { if (current === c) { try { onEvent(JSON.parse(message.data)); } catch {} } };
        c.dc.onclose = () => { if (current === c) void stop('실시간 통신이 종료됐습니다.'); };
        await c.pc.setLocalDescription(await c.pc.createOffer());
        if (current !== c) return;
        sdp = c.pc.localDescription.sdp;
      }
      const result = await phone.api('realtime/start',{sdp,mock});
      if (current !== c) { await phone.api('realtime/stop',{session_id:result.session_id}).catch(()=>{}); return; }
      c.id = result.session_id;
      if (!mock) await c.pc.setRemoteDescription({type:'answer',sdp:result.sdp});
      else { c.ready = true; status('모의 연결됨 · 음성 인식과 AI 분석은 하지 않아요'); }
      if (current !== c) return;
      c.timer = setInterval(()=>{ void heartbeat(c); void frames(c); },2000);
      c.limit = setTimeout(()=>void stop('5분 세션이 끝났습니다. 필요하면 다시 시작하세요.'),300000);
      c.connectLimit = setTimeout(()=>{ if (current === c && !c.ready) void stop('실시간 연결 시간이 초과됐습니다.'); },20000);
      controls(); phase('listening'); void frames(c);
    } catch (error) {
      const message = error.name === 'NotAllowedError' ? '마이크 사용을 허용한 뒤 자동 대화를 시작해 주세요.' :
        error.name === 'NotFoundError' ? '마이크를 찾지 못했어요. USB 마이크를 연결한 뒤 다시 시작해 주세요.' : '연결 실패: ' + error.message;
      if (current === c) await stop(message);
    }
  }
  async function stop(message='실시간 꺼짐') {
    const c = current; if (!c) return;
    current = null; ++generation;
    clearInterval(c.timer); clearTimeout(c.limit); clearTimeout(c.connectLimit); clearTimeout(c.disconnectTimer); clearTimeout(c.sampleTimer);
    c.stream?.getTracks().forEach(t=>t.stop());
    c.dc?.close(); c.pc?.close(); audio.pause(); audio.srcObject = null; el('rt-audio').hidden = true;
    el('rt-vision').checked = false; el('rt-frames').textContent = '프레임 전송 꺼짐';
    status(message); if (message !== '실시간 꺼짐') el('error').textContent = message; controls(); phone.restore();
    if (c.id) {
      try {
        if (c.pending.length) await phone.api('realtime/heartbeat',{session_id:c.id,phase:'listening',events:c.pending.slice(0,8)});
      } catch {}
      try { const result = await phone.api('realtime/stop',{session_id:c.id}); if (result.warning) status(result.warning); }
      catch { status(message + ' · PC 종료 확인 실패, 30초 후 자동 종료를 시도합니다.'); }
    }
    void phone.restore();
  }
  function interrupt() {
    const c = current; if (!c) return;
    if (c.playing) c.interruptAt = performance.now();
    if (!c.mock) { if (c.responding) send({type:'response.cancel'}); if (c.playing) send({type:'output_audio_buffer.clear'}); }
    c.responding = false; c.playing = false; phase('listening');
  }
  el('rt-start').onclick = ()=>start(false); el('rt-mock').onclick = ()=>start(true);
  el('handsfree').onclick = ()=>current ? stop() : start(false);
  el('rt-stop').onclick = ()=>stop(); el('rt-interrupt').onclick = interrupt; el('rt-audio').onclick = playAudio;
  el('rt-mute').onclick = () => { if (!current?.stream) return; current.muted = !current.muted; current.stream.getAudioTracks().forEach(t=>t.enabled=!current.muted); el('rt-mute').textContent = current.muted ? '마이크 켜기' : '마이크 끄기'; controls(); phase(current.playing?'speaking':current.responding?'thinking':'listening'); };
  el('handsfree-mute').onclick = ()=>el('rt-mute').onclick();
  el('rt-vision').onchange = () => { if (!current) { el('rt-vision').checked = false; return; } if (!el('rt-vision').checked) { visualAbsent(current); current.frameVersion = -1; current.noFrames = true; el('rt-frames').textContent = '프레임 전송 꺼짐'; } else void frames(current); };
  el('rt-sample').onclick = () => {
    if (!current?.mock) return;
    const c = current, id = 'mock_' + (++c.frameSerial);
    clearTimeout(c.sampleTimer);
    transcript({item_id:id},'user','[모의 자막] 사진들 사이에서 무엇이 바뀌었어?');
    phase('thinking');
    c.sampleTimer = setTimeout(()=>{
      if (current !== c) return;
      phase('speaking'); transcript({item_id:id},'assistant','[모의 답변] 실제 분석 전이야. 준비한 사진 순서와 연결 흐름을 확인하고 있어.');
      c.sampleTimer = setTimeout(()=>{ if (current === c) phase('listening'); },1800);
    },1200);
  };
  document.addEventListener('visibilitychange',()=>{ if (document.hidden && current) void stop('화면을 벗어나 실시간 대화를 종료했습니다.'); });
  window.addEventListener('pagehide',()=>{ if (current) void stop(); });
  window.BmoRealtime = {active:()=>!!current,interrupt,stop,update:s=>{ shared=s; controls(); if (!current && s.realtime?.active) status('다른 화면에서 실시간 대화 중'); }};
  if (phone.state()) window.BmoRealtime.update(phone.state());
})();
